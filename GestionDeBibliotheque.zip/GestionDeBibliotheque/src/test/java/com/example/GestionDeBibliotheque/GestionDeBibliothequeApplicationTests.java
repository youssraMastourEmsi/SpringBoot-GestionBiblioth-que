package com.example.GestionDeBibliotheque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDeBibliothequeApplicationTests {

	@Test
	void contextLoads() {
	}

}
